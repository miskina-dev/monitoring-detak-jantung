<?php
// Memulai sesi
session_start();

// Konfigurasi database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "detakjantung";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to safely escape user inputs
function safeInput($data) {
    global $conn;
    return mysqli_real_escape_string($conn, trim($data));
}
?>
