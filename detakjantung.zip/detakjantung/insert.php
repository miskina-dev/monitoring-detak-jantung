<?php
session_start();

$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "detakjantung";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk mengamankan input dari user
function safeInput($data, $conn) {
    return mysqli_real_escape_string($conn, htmlspecialchars($data));
}

// Cek apakah ada data yang dikirimkan melalui metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari POST
    $bpm = safeInput($_POST["bpm"], $conn);
    $status = safeInput($_POST["status"], $conn);
    $pasien_id = 4; // Sesuaikan dengan pasien_id yang ingin Anda gunakan
    $tanggal = date("Y-m-d H:i:s");

    // Query untuk menyimpan data ke dalam tabel datajantung
    $sql = "INSERT INTO datajantung (pasien_id, bpm, tanggal, status) VALUES ('$pasien_id', '$bpm', '$tanggal', '$status')";

    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil disimpan";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Metode pengiriman data tidak valid";
}

$conn->close();
?>
