<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = safeInput($_POST['nama']);
    $tanggal_lahir = safeInput($_POST['tanggal_lahir']);
    $alamat = safeInput($_POST['alamat']);
    $jenis_kelamin = safeInput($_POST['jenis_kelamin']);
    $nohp = safeInput($_POST['nohp']);

    $sql = "INSERT INTO pasien (nama, tanggal_lahir, alamat, jenis_kelamin, nohp) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $nama, $tanggal_lahir, $alamat, $jenis_kelamin, $nohp);

    if ($stmt->execute()) {
        echo "Data berhasil disimpan!";
        header('Location: forminput.php');
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
