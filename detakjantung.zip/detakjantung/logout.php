<?php
include 'config.php';

// Menghapus semua variabel sesi
session_unset();

// Menghancurkan sesi
session_destroy();

header('Location: login.php');
exit();
?>
