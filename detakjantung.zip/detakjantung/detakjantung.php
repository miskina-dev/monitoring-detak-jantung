<?php
include 'config.php';

// Fungsi untuk mendapatkan data BPM berdasarkan pasien_id
function getBPMData($conn, $pasien_id) {
    $sql = "SELECT bpm, tanggal, status FROM datajantung WHERE pasien_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $pasien_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $labels = [];
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $labels[] = $row['tanggal'];
        $data[] = $row['bpm'];
    }

    $stmt->close();
    return ['labels' => $labels, 'data' => $data];
}

// Jika ini adalah permintaan AJAX, kirim data sebagai JSON
if (isset($_GET['ajax']) && isset($_GET['pasien_id'])) {
    $pasien_id = intval($_GET['pasien_id']);
    $bpmData = getBPMData($conn, $pasien_id);
    echo json_encode($bpmData);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Deteksi Detak Jantung</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Updated: Apr 20 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">Deteksi Detak Jantung</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <nav class="header-nav ms-auto">
      
    </nav><!-- End Icons Navigation -->
  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
      <a class="nav-link " href="index.php">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    </li><!-- End Dashboard Nav -->

    <li class="nav-item">
      <a class="nav-link " href="forminput.php">
        <i class="bi bi-grid"></i>
        <span>Form Input</span>
      </a>
    </li><!-- End Dashboard Nav -->

    <li class="nav-item">
      <a class="nav-link " href="datapasien.php">
        <i class="bi bi-grid"></i>
        <span>Data Pasien</span>
      </a>
    </li><!-- End Dashboard Nav -->

    <li class="nav-item">
      <a class="nav-link " href="detakjantung.php">
        <i class="bi bi-grid"></i>
        <span>Detak Jantung</span>
      </a>
    </li><!-- End Dashboard Nav -->

    <li class="nav-item">
      <a class="nav-link " href="logout.php">
        <i class="bi bi-grid"></i>
        <span>Logout</span>
      </a>
    </li><!-- End Dashboard Nav -->

  </ul>

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <section class="section">
    <div class="content">
            <h2>Grafik Detak Jantung</h2>
            <form id="userForm">
                <label for="pasien_id">Pilih User:</label>
                <select id="pasien_id" name="pasien_id">
                    <option value="">-- Pilih User --</option>
                    <?php
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $sql = "SELECT id, nama FROM pasien";
                    $result = $conn->query($sql);

                    while ($pasien = $result->fetch_assoc()) {
                        echo "<option value='" . $pasien['id'] . "'>" . $pasien['nama'] . "</option>";
                    }

                    $conn->close();
                    ?>
                </select>
            </form>
            <canvas id="lineChart"></canvas>
        </div>
    </section>

  </main><!-- End #main -->
  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
        $(document).ready(function() {
            $('#pasien_id').change(function() {
                var pasien_id = $(this).val();
                if (pasien_id) {
                    $.ajax({
                        url: 'detakjantung.php',
                        type: 'GET',
                        data: {
                            ajax: 1,
                            pasien_id: pasien_id
                        },
                        success: function(response) {
                            var bpmData = JSON.parse(response);
                            console.log('Data retrieved:', bpmData); // Debugging: Check the data retrieved
                            updateChart(bpmData.labels, bpmData.data);
                            updateTable(pasien_id);
                        },
                        error: function(xhr, status, error) {
                            console.error('AJAX Error:', status, error);
                        }
                    });
                }
            });

            function updateChart(labels, data) {
                var ctx = document.getElementById('lineChart').getContext('2d');
                if (window.myLineChart) {
                    window.myLineChart.destroy();
                }
                window.myLineChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'BPM',
                            data: data,
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1,
                            fill: false
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            x: {
                                title: {
                                    display: true,
                                    text: 'Tanggal'
                                }
                            },
                            y: {
                                title: {
                                    display: true,
                                    text: 'BPM'
                                }
                            }
                        }
                    }
                });
            }

            function updateTable(pasien_id) {
                $.ajax({
                    url: 'detakjantung.php',
                    type: 'GET',
                    data: {
                        pasien_id: pasien_id
                    },
                    success: function(response) {
                        var parser = new DOMParser();
                        var doc = parser.parseFromString(response, 'text/html');
                        var newTableRows = doc.querySelectorAll('table tbody tr');
                        var tbody = document.getElementById('bpmData');
                        tbody.innerHTML = '';
                        newTableRows.forEach(function(row) {
                            tbody.appendChild(row);
                        });
                    }
                });
            }
        });
    </script>
</body>

</html>